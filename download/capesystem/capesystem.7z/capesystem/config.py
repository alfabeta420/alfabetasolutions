# Embed color (hex)
embedcolor = 0x0000ff
# Embed footer text
embedfootertext = "Alfabeta.solutions"
# Embed footer icon link
embedfootericon = "https://i.imgur.com/hB030bf.png"
# Embed thumbnail link
embedthumbnail = "https://i.imgur.com/hB030bf.png"
# Acivity type. Available options: NONE, PLAYING, WATCHING, LISTENING, STREAMING, COMPETING
activitytype = "WATCHING"
# Twitch url (optional)
streamingurl = "https://www.twitch.tv/izakooo"
# Activity text
activitytext = "alfabeta.solutions"
# Bot status. Available options: DND, IDLE, ONLINE, INVISIBLE
status = "DND"
# Allow using /register command only in that channel. Type a channel ID.
registerchannelid = 0000000000000000
# Allow using /cape command only in that channel. Type a channel ID.
capechannelid = 0000000000000000
# Cape list channel. Type a channel ID.
capelistchannelid = 0000000000000000







# Scroll down to set the token
# Be careful to not leak it!



































































# Go to https://discord.dev/ to get your bot token
token = "token"