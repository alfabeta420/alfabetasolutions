This project was downloaded from alfabeta.solutions!




Warning: if you host this on your PC and you use it you won't see optifine users' capes. Hosting this project on a vps is recommended!




To redirect all connections from optifine server to your vps use hosts file located in C:\Windows\System32\drivers\etc\hosts.
Just add there a line: 

0.0.0.0 s.optifine.net

And then change '0.0.0.0' to your vps IPv4.

If something doesn't work open cmd and type 'ipconfig /flushdns'.




Modules to install:
- flask
- py-cord==2.0.0rc1




Have fun with my custom optifine capes system!
https://alfabeta.solutions/
https://github.com/alfabeta420